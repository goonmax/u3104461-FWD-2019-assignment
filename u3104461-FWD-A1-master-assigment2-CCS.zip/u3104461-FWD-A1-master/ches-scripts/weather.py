import requests

city = input('Enter your city : ')
url  = 'https://api.openweathermap.org/data/2.5/weather?q=&appid=85f88360a5fbc93d8b408712ed83faee'
